select*from country left outer join city on city.name = null ;

