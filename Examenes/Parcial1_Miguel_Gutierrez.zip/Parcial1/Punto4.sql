select language,sum(habladores) from(select name, countrylanguage.language , (countrylanguage.percentage/100)*population as habladores from country join countrylanguage on country.code = countrylanguage.countrycode)as A group by a.language order by language;


