select name from country,indepyear where indepyear <= 1900 and not null;
