select continent,region,count(*) as numero_paises from country group by continent,region;


