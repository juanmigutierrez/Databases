create trigger aumento_cit
after insert on city
for each row
execute procedure aumento_cit()

create or replace function aumento_cit()
returns trigger as
$$
begin
	update country
		set population = population +(select population from city where id = new.id) where code = new.countrycode;
		return new;
end;
$$
language 'plpgsql'

drop function aumento_cit() cascade;
select*from country where code = 'CHL';
