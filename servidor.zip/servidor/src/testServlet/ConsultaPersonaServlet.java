package testServlet;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.*;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

@WebServlet("/testServlet/consultaPersona")
public class ConsultaPersonaServlet extends HttpServlet{

	public void doGet(HttpServletRequest request,
	HttpServletResponse response)
	throws ServletException, IOException
	{
	    
		//CODIGO SQL
		System.out.println("Estableciendo conexi�n...");
        try (Connection conexion = DriverManager.getConnection("jdbc:postgresql://localhost:5432/taller8", "postgres", "postgres")){
 
            
            System.out.println("Conexion con la base de datos establecida (PostgreSQL)");
            Statement statement = conexion.createStatement();
            
          //Ejemplo inserci�n
           // System.out.println("Consultando la base de datos...");
            //statement.executeUpdate("insert into curso values ('005', 'probabilidad', 'MACC', 3);");
            
          //Ejemplo consulta
            System.out.println("Consultando la base de datos...");
            
            response.setContentType("text/html");
    		PrintWriter out= response.getWriter();
    		out.println("printer creado");
    		
    		out.println("<html>");
    	    out.println("<body>");
    	    out.println("<h1>Hola Mundo</h1>");
    	    out.println("</body>");
    	    out.println("</html>");
    		
    		/*out.println("<HEAD><TITLE> Query Result</TITLE></HEAD>");
    		out.println("<BODY>");
    		String persontype = request.getParameter("tipoPersona");
    	    String number = request.getParameter("nombre");
    		out.println("<table BORDER COLS=3>"); 
    		out.println(" <tr> <td>ID</td> <td>Nombre: </td>" +
    				" <td>Departamento</td> </tr>");
    		
    		ResultSet resultSet = statement.executeQuery("select nombres from estudiante where nombres =" + number);
    		
    		int ID = 0;
    		String nombre = null;
    		String depto = null;
    		if(resultSet!=null) {
    			out.println("result set has got something");
    		}
    		else {
    			out.println("No esta lol");
    		}
    		out.println("<tr> <td>" + ID + "</td>" +
    				"<td>" + nombre + "</td>" +
    				"<td>" + depto + "</td></tr>");
    			
    		out.println("</table>");
    		out.println("</BODY>");
    		out.close();*/
            
        }
        
        catch (SQLException e) {
            System.out.println("Conexi�n fallida");
            e.printStackTrace();
        }
	}
}