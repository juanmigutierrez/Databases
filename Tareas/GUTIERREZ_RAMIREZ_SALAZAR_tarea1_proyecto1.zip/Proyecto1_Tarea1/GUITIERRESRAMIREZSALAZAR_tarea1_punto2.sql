Create table Usuario(
	ID varchar(20),
	Contrasena varchar(20),
	primary key(ID)
);

Create table Cuenta(
	cod_cuenta varchar(20),
	saldo numeric(10,3),
	primary key(cuenta)
);

Create table Usuario_Externo(
	ID_ex varchar(20),
	cod_cuenta_ex varchar(20),
	Banco varchar(20),
	primary key(ID,Cuenta)
);

---------------------------------------------
--Relaciones

Create table Retiro(
	ID varchar(20),
	cod_cuenta varchar(20),
	lugar varchar(20),
	monto numeric(10,3),
	fecha date,
	hora time,
	primary key(cod_cuenta),
	foreign key(ID) references Usuario(ID),
	foreign key(cod_cuenta) references Cuenta(cod_cuenta)
);

Create table Transferencia_Interna(
	ID_envia varchar(20),
	ID_recibe varchar(20),
	cod_cuenta_envia varchar(20),
	cod_cuenta_recibe varchar(20),
	monto numeric(10,3),
	fecha date,
	hora time,
	primary key(cod_cuenta_envia,cod_cuenta_recibe),
	foreign key(ID_envia) references Usuario(ID),
	foreign key(ID_recibe) references Usuario(ID),
	foreign key(cod_cuenta_envia) references Cuenta(cod_cuenta),
	foreign key(cod_cuenta_recibe) references Cuenta(cod_cuenta)
);

Create table Transferencia_externa(
	ID varchar(20),
	ID_ex varchar(20),
	cod_cuenta_ex varchar(20),
	cod_cuenta varchar(20),
	monto numeric(10,3),
	Banco varchar(20),
	fecha date,
	hora time,
	primary key(cod_cuenta),
	foreign key(ID) references Usuario(ID),
	foreign key(ID_ex,cod_cuenta_ex) references Usuario_Externo(ID_ex,cod_cuenta_ex),
	foreign key(cod_cuenta) references Cuenta(cod_cuenta)
);

Create table Servicios_UR(
	cod_cuenta varchar(20),
	ID varchar(20),
	servicio varchar(30),
	monto numeric(10,3),
	fecha date,
	hora time,
	primary key(cod_cuenta),
	foreign key(ID) references Usuario(ID),
	foreign key(cod_cuenta) references Cuenta(cod_cuenta)
);