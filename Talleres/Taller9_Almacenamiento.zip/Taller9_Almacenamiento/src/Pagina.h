/*
 * Pagina.h
 *
 *  Created on: Apr 26, 2019
 *      Author: lovelace
 */

#ifndef SRC_PAGINA_H_
#define SRC_PAGINA_H_

#include <iostream>
#include <list>
#include <string>
#include <map>
#include "Tupla.h"

using namespace std;

class Pagina{

private:



public:
	Pagina();
	~Pagina();
	int agregar_tupla(Tupla tupla);
	void quitar_tupla(Tupla tupla);

	const int MAX = 4096;
	int espacios_usados;
	int ubicacion;
	list<Tupla> apuntador;
	int contador;
	int id;
	         // pos ,tam
	map<int,pair<int,int>> posicion_tamano;

	int getEspaciosUsados();

};
// ACA COLOCO INCLUDE TUPLA.CPP ?

#endif /* SRC_PAGINA_H_ */
