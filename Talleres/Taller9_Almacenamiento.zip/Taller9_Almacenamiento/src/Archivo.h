/*
 * Archivo.h
 *
 *  Created on: Apr 26, 2019
 *      Author: lovelace
 */

#ifndef SRC_ARCHIVO_H_
#define SRC_ARCHIVO_H_

#include <iostream>
#include <list>
#include <string>
#include "Tupla.h"
#include "Pagina.h"
#include <map>

using namespace std;

class Archivo{
private:
	list<Pagina> directorio;
	string nombre;//CAMBIAR INT POR TUPLA
	int contador;
	string *arreglo = new string[2]; // ACA VAN LOS CAMPOS

	public :
	Archivo ();
	~Archivo ();
	void agregar_tupla(Tupla tupla);
	void quitar_tupla(Tupla tupla);
	void leer_tupla(Tupla tupla);
	void leer_nombre(string nombre);

};

#endif /* SRC_ARCHIVO_H_ */
