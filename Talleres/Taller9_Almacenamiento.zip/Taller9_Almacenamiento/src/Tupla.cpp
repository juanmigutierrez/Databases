/*
 * Tupla.cpp
 *
 *  Created on: May 8, 2019
 *      Author: lovelace
 */

#include "Tupla.h"
#include <iostream>


using namespace std;
//Tupla Constructor

Tupla::Tupla(string Nombre1,string apellido1,int id1)
{
	Nombre = Nombre1;
	apellido = apellido1;
	id = id1;
	//apuntadores(# de campos necesito9

};

Tupla::~Tupla()
{

};

int Tupla::Size_of()
{
	int bytes = sizeof(Nombre)+sizeof(apellido)+sizeof(id);
	return bytes;
}

string Tupla::get_nombre(){
	return this->Nombre;
}

bool Tupla::operator ==(Tupla tupla)
{
	if(tupla.Nombre == this->Nombre and tupla.apellido == this->apellido)
	{
		return true;
	}
	else
	{
		return false;
	}
}
