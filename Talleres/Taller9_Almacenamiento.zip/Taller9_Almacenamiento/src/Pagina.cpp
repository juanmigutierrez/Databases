/*
 * Pagina.cpp
 *
 *  Created on: May 8, 2019
 *      Author: lovelace
 */



#include <list>
#include "Pagina.h"
#include <iostream>


using namespace std;

Pagina::Pagina()
{
	this->espacios_usados = 0;
	ubicacion = 4096;
	contador = 0;
	id = 0;
	apuntador = list<Tupla>();
	// ACA NO COLOCO NEW LIST

	//apuntador = new Tupla*[10];
	//arreglo = new Tupla[10]

}

Pagina::~Pagina()
{

}

int Pagina::agregar_tupla(Tupla tupla){
	cout << this-> espacios_usados << endl;

	if(espacios_usados <= MAX or tupla.Size_of() + espacios_usados <= MAX )
	{
	espacios_usados = tupla.Size_of() + espacios_usados;// Size_of
	ubicacion = MAX -espacios_usados;
	pair<int,int> parf;
	parf.first = ubicacion;
	parf.second = espacios_usados;
	posicion_tamano.insert(pair<int,pair<int,int>>(contador,parf));
	tupla.id = contador;
	contador = contador +1;
	apuntador.push_back(tupla);
	cout << "agregado" << endl;
	return 1;
	}
	else
	{
	cout << "No se puede agregar, ya esta llena la pagina" << endl;
	return 0;
	}

}

void Pagina::quitar_tupla(Tupla tupla)
{
	espacios_usados = espacios_usados - tupla.Size_of();
	ubicacion = MAX - espacios_usados;
	map<int,pair<int,int>>::iterator it;
	int id = tupla.id;
	it = posicion_tamano.find(id);
	posicion_tamano.erase(it);
	apuntador.remove(tupla);// Aca no le bajo el contador
}

int Pagina::getEspaciosUsados()
{
	return this->espacios_usados;
}



