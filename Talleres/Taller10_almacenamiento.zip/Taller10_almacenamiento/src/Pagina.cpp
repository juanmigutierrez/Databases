/*
 * Pagina.cpp
 *
 *  Created on: May 8, 2019
 *      Author: lovelace
 */



#include <list>
#include "Pagina.h"
#include <iostream>
#include<iostream>
#include<fstream>
#include<cstdio>

using namespace std;

Pagina::Pagina()
{
	this->espacios_usados = 0;
	ubicacion = 4096;
	contador = 0;
	id = 0;
	apuntador = list<Tupla>();

	fstream file;
	file.open("Pagina"+to_string(id)+".dat",ios::in | ios::out);
	file.close();

}

Pagina::~Pagina()
{

}

int Pagina::agregar_tupla(Tupla tupla){
	cout << this-> espacios_usados << endl;

	if(espacios_usados <= MAX or tupla.Size_of() + espacios_usados <= MAX )
	{


	espacios_usados = tupla.Size_of() + espacios_usados;// Size_of
	ubicacion = MAX -espacios_usados;
	pair<int,int> parf;
	parf.first = ubicacion;
	parf.second = espacios_usados;
	posicion_tamano.insert(pair<int,pair<int,int>>(contador,parf));
	tupla.id = contador;
	contador = contador +1;
	apuntador.push_back(tupla);
	cout << "agregado" << endl;

	ifstream inFile;
	inFile.open("Pagina"+to_string(id)+".dat", ios::binary);

	ofstream outFile2;
	outFile2.open("temp.dat", ios::out | ios::binary);

	return 1;
	}
	else
	{
	cout << "No se puede agregar, ya esta llena la pagina" << endl;
	return 0;
	}

}

void Pagina::quitar_tupla(Tupla tupla)
{
	espacios_usados = espacios_usados - tupla.Size_of();
	ubicacion = MAX - espacios_usados;
	map<int,pair<int,int>>::iterator it;
	int id = tupla.id;
	it = posicion_tamano.find(id);
	posicion_tamano.erase(it);
	apuntador.remove(tupla);// Aca no le bajo el contador
}

int Pagina::getEspaciosUsados()
{
	return this->espacios_usados;
}



