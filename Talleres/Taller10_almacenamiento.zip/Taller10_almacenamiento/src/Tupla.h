/*
 * Tupla.h
 *
 *  Created on: Apr 26, 2019
 *      Author: lovelace
 */

#ifndef SRC_TUPLA_H_
#define SRC_TUPLA_H_


#include <iostream>
#include <list>
#include <string>


using namespace std;

class Tupla{

	private:


	public :
	int id;
	string Nombre;
	string apellido;

	Tupla(string Nombre,string apellido,int id) ;
	~Tupla();
	int Size_of();
	string get_nombre();
	bool operator == (Tupla tupla);


};


#endif /* SRC_TUPLA_H_ */
