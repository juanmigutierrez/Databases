/*
 * Binary.h
 *
 *  Created on: May 17, 2019
 *      Author: lovelace
 */

#ifndef SRC_BINARY_H_
#define SRC_BINARY_H_





#endif /* SRC_BINARY_H_ */
