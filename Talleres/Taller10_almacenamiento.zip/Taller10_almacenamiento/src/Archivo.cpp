/*
 * Archivo.cpp
 *
 *  Created on: May 8, 2019
 *      Author: lovelace
 */



#include <iostream>
#include "Archivo.h"

using namespace std;

Archivo::Archivo(){
	Pagina pagina = Pagina();
	contador = 0;
	directorio = list<Pagina>();
	pagina.id = contador;
	directorio.push_back(pagina);
	contador = contador +1;


}

Archivo::~Archivo()
{

}

void Archivo::agregar_tupla(Tupla tupla)
{
	list<Pagina>::iterator it;

	int return1 = 0;

	for(it = directorio.begin();it != directorio.end();it++)
	{
		if(it->espacios_usados <= it->MAX or (tupla.Size_of() + it->espacios_usados) <= it->MAX )
		{
			return1 = (*it).agregar_tupla(tupla);
			break;
		}
	}
	if(return1==0)
	{
		Pagina pagina = Pagina();
		cout << "Se creo otra pagina " << endl;
		pagina.id = contador;
		contador = contador +1 ;
		pagina.agregar_tupla(tupla);
	}
	else{
		cout << "ya entro" << endl;
	}
}

void Archivo::quitar_tupla(Tupla tupla)
{
	map<int,pair<int,int>>::iterator it1;

	list<Pagina>::iterator it;
	list<Tupla>::iterator it2;

	for(it = directorio.begin();it != directorio.end();it++)
		{
			for(it2 = (*it).apuntador.begin();it2 !=(*it).apuntador.end();it2++)
			{
				if((*it2).Nombre==tupla.Nombre and (*it2).apellido == tupla.apellido)
				{
					(*it).quitar_tupla(tupla);
					return;

				}
			}
		}
	cout << "No lo encontro en ninguna pagina" << endl;


}

void Archivo::leer_tupla(Tupla tupla) // HACER LISTA TUPLAS
{
	list<Pagina>::iterator it;
	list<Tupla>::iterator it2;
	for(it = directorio.begin();it != directorio.end();it++)
	{
		for(it2 = (*it).apuntador.begin();it2 !=(*it).apuntador.end();it2++)
		{
			if((*it2).Nombre==tupla.Nombre and (*it2).apellido == tupla.apellido)
			{
				cout << "Tupla:" << endl;
				cout << (*it2).Nombre << endl;
				cout << (*it2).apellido << endl;
				return;

			}
		}
	}
	cout << "No lo encontro" << endl;
}

