/*
 * Prueba.cpp
 *
 *  Created on: May 9, 2019
 *      Author: lovelace
 */




#include <iostream>
#include <iostream>
#include <list>
#include <string>
#include <map>
#include "Archivo.h"

using namespace std;
/**
int main(){

	Archivo archivo1  = Archivo();

	Tupla tupla1 = Tupla("Jose","Mario",0);
	Tupla tupla2 = Tupla("Moises","Carolos",0);


	archivo1.agregar_tupla(tupla1);
	archivo1.agregar_tupla(tupla2);

	archivo1.leer_tupla(tupla1);

	archivo1.quitar_tupla(tupla1);

	archivo1.leer_tupla(tupla2);


}**/










