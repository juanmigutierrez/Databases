/*
 * nodo.h
 *
 *  Created on: May 17, 2019
 *      Author: lovelace
 */

#ifndef SRC_NODO_H_
#define SRC_NODO_H_

#include "Tupla.h"

class nodo
{

	public:
	const int n = 5;
	bool es_hoja;
	string *arreglo = new string[n-1];

	nodo* next;
	Tupla** arreglo_tuplas;
	nodo** hijos;

	nodo();
	nodo(bool es_hoja);
	~nodo();
};


#endif /* SRC_NODO_H_ */
