/*
 * prueba.cpp
 *
 *  Created on: May 17, 2019
 *      Author: lovelace
 */




#include <iostream>
#include <iostream>
#include <list>
#include <string>
#include <map>

using namespace std;

int main(){


}
