/*
 * nodo.cpp
 *
 *  Created on: May 17, 2019
 *      Author: lovelace
 */




#include <iostream>
#include "nodo.h"


nodo::nodo(bool es_hoja1){
	if(es_hoja1 == true)
	{
		next = NULL;
		arreglo_tuplas= new Tupla*[(n-1)];
	}
	else
	{
		next = NULL;
	}
}

nodo::nodo()
{
	cout << "Este constructor no se utiliza" << endl;
}

nodo::~nodo()
{

}
