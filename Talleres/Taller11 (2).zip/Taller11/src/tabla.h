/*
 * tabla.h
 *
 *  Created on: May 17, 2019
 *      Author: lovelace
 */

#ifndef SRC_TABLA_H_
#define SRC_TABLA_H_

#include "Tupla.h"
#include <list>
#include "Bplus.h"

class tabla
{
	list<Tupla> lista;
	int identificador;
	Bplus indice;
};

#endif /* SRC_TABLA_H_ */
