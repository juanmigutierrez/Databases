/*
 * Bplus.h
 *
 *  Created on: May 17, 2019
 *      Author: lovelace
 */

#ifndef SRC_BPLUS_H_
#define SRC_BPLUS_H_

#include <iostream>
#include <list>
#include <string>
#include "nodo.h"

using namespace std;

class Bplus
{
	nodo* raiz;
	const int n=5;
};

#endif /* SRC_BPLUS_H_ */
